// // models/Image.js

// const mongoose = require('mongoose');

// const imageSchema = new mongoose.Schema({
//   img: {
//     type: String,
//     required: true,
//   },
//   title: {
//     type: String,
//     required: true,
//   },
//   // Add other fields as needed
// });

// const Image = mongoose.model('Image', imageSchema);

// module.exports = Image;
